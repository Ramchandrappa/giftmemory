# GiftMemory – Thoughtful Gift Planner

React + Node.js/Express + MongoDB.

## Run it

1. Start MongoDB (local or Atlas).
2. Backend
   ```
   cd server
   cp .env.example .env      # edit MONGO_URI and JWT_SECRET
   npm install
   npm run seed              # optional demo data: demo@giftmemory.app / demo123
   npm run dev               # http://localhost:5000
   ```
3. Frontend (new terminal)
   ```
   cd client
   cp .env.example .env
   npm install
   npm run dev               # http://localhost:5173
   ```

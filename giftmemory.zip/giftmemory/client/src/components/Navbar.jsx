import { Link, NavLink } from 'react-router-dom';
import { useAuth } from '../AuthContext';

export default function Navbar() {
  const { user, logout } = useAuth();
  return (
    <header className="navbar">
      <Link to="/" className="brand">🎁 GiftMemory</Link>
      {user && (
        <nav>
          <NavLink to="/" end>Dashboard</NavLink>
          <NavLink to="/recipients">Recipients</NavLink>
          <button className="link" onClick={logout}>Log out</button>
        </nav>
      )}
    </header>
  );
}

import axios from 'axios';

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || 'http://localhost:5000/api',
});

// Attach the JWT to every request
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('gm_token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

// Turn API errors into a readable message
export function errorMessage(err) {
  const e = err?.response?.data?.error;
  if (!e) return 'Cannot reach the server. Is it running?';
  if (Array.isArray(e.details) && e.details.length) {
    return e.details.map((d) => d.message).join(', ');
  }
  return e.message;
}

export default api;

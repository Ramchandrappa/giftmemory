import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api, { errorMessage } from '../api';

const empty = { name: '', relationship: '', likes: '', dislikes: '' };
const toList = (s) => s.split(',').map((x) => x.trim()).filter(Boolean);

export default function Recipients() {
  const [list, setList] = useState([]);
  const [form, setForm] = useState(empty);
  const [error, setError] = useState('');

  const load = () => api.get('/recipients').then((r) => setList(r.data)).catch((e) => setError(errorMessage(e)));
  useEffect(() => { load(); }, []);

  const submit = async (e) => {
    e.preventDefault();
    if (!form.name.trim()) return setError('Name is required');
    try {
      await api.post('/recipients', {
        name: form.name,
        relationship: form.relationship,
        preferences: { likes: toList(form.likes), dislikes: toList(form.dislikes) },
      });
      setForm(empty);
      setError('');
      load();
    } catch (err) {
      setError(errorMessage(err));
    }
  };

  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  return (
    <section className="two-col">
      <div>
        <h1>Recipients</h1>
        {!list.length && <p className="muted">No recipients yet. Add someone you buy gifts for.</p>}
        <ul className="list">
          {list.map((r) => (
            <li key={r._id} className="card">
              <Link to={`/recipients/${r._id}`}><b>{r.name}</b></Link>
              <span className="muted"> {r.relationship}</span>
              {r.preferences?.likes?.length > 0 && <p className="small">Likes: {r.preferences.likes.join(', ')}</p>}
            </li>
          ))}
        </ul>
      </div>
      <form className="card" onSubmit={submit} noValidate>
        <h2>Add recipient</h2>
        {error && <p className="alert error">{error}</p>}
        <label>Name *<input value={form.name} onChange={set('name')} /></label>
        <label>Relationship<input value={form.relationship} onChange={set('relationship')} placeholder="Mother, friend…" /></label>
        <label>Likes (comma separated)<input value={form.likes} onChange={set('likes')} /></label>
        <label>Dislikes (comma separated)<input value={form.dislikes} onChange={set('dislikes')} /></label>
        <button>Add</button>
      </form>
    </section>
  );
}

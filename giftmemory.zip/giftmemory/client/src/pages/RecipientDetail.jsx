import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import api, { errorMessage } from '../api';

const fmtDate = (d) => (d ? new Date(d).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' }) : '');

export default function RecipientDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [data, setData] = useState(null);
  const [error, setError] = useState('');
  const [occ, setOcc] = useState({ title: '', date: '', budget: '', recurring: true });
  const [gift, setGift] = useState({ name: '', price: '', occasionId: '' });
  const [warning, setWarning] = useState(null); // duplicate matches

  const load = () =>
    api.get(`/recipients/${id}`).then((r) => setData(r.data)).catch((e) => setError(errorMessage(e)));
  useEffect(() => { load(); }, [id]);

  const addOccasion = async (e) => {
    e.preventDefault();
    if (!occ.title.trim() || !occ.date) return setError('Occasion title and date are required');
    if (occ.budget && Number(occ.budget) < 0) return setError('Budget must be 0 or more');
    try {
      await api.post('/occasions', { recipientId: id, ...occ, budget: Number(occ.budget) || 0 });
      setOcc({ title: '', date: '', budget: '', recurring: true });
      setError('');
      load();
    } catch (err) {
      setError(errorMessage(err));
    }
  };

  const saveGift = async (force = false) => {
    try {
      await api.post('/gifts', {
        recipientId: id,
        name: gift.name,
        price: Number(gift.price) || 0,
        occasionId: gift.occasionId || undefined,
        force,
      });
      setGift({ name: '', price: '', occasionId: '' });
      setWarning(null);
      setError('');
      load();
    } catch (err) {
      if (err.response?.status === 409) setWarning(err.response.data.error.details.matches);
      else setError(errorMessage(err));
    }
  };

  const addGift = (e) => {
    e.preventDefault();
    if (!gift.name.trim()) return setError('Gift name is required');
    if (gift.price && Number(gift.price) < 0) return setError('Price must be 0 or more');
    saveGift(false);
  };

  const markGiven = async (g) => {
    const price = window.prompt(`Actual price paid for "${g.name}"?`, g.price || 0);
    if (price === null) return;
    try {
      await api.patch(`/gifts/${g._id}/given`, { price: Number(price) || 0 });
      load();
    } catch (err) {
      setError(errorMessage(err));
    }
  };

  const remove = async () => {
    if (!window.confirm('Delete this recipient and all their occasions and gifts?')) return;
    await api.delete(`/recipients/${id}`);
    navigate('/recipients');
  };

  if (!data) return error ? <p className="alert error">{error}</p> : <p className="muted">Loading…</p>;
  const { recipient, occasions, gifts } = data;
  const ideas = gifts.filter((g) => g.status === 'idea');
  const given = gifts.filter((g) => g.status === 'given');

  return (
    <section>
      <div className="row-between">
        <h1>{recipient.name} <span className="muted">{recipient.relationship}</span></h1>
        <button className="danger" onClick={remove}>Delete</button>
      </div>
      {error && <p className="alert error">{error}</p>}

      <div className="grid">
        <div className="card">
          <h2>Preferences</h2>
          <p><b>Likes:</b> {recipient.preferences?.likes?.join(', ') || '—'}</p>
          <p><b>Dislikes:</b> {recipient.preferences?.dislikes?.join(', ') || '—'}</p>
        </div>

        <div className="card">
          <h2>Occasions</h2>
          <ul className="plain">
            {occasions.map((o) => (
              <li key={o._id}>{o.title} · {fmtDate(o.date)}{o.recurring && ' (yearly)'}{o.budget > 0 && ` · ₹${o.budget}`}</li>
            ))}
          </ul>
          <form onSubmit={addOccasion} noValidate>
            <input placeholder="Title, e.g. Birthday" value={occ.title} onChange={(e) => setOcc({ ...occ, title: e.target.value })} />
            <input type="date" value={occ.date} onChange={(e) => setOcc({ ...occ, date: e.target.value })} />
            <input type="number" min="0" placeholder="Budget ₹" value={occ.budget} onChange={(e) => setOcc({ ...occ, budget: e.target.value })} />
            <label className="check"><input type="checkbox" checked={occ.recurring} onChange={(e) => setOcc({ ...occ, recurring: e.target.checked })} /> Repeats yearly</label>
            <button>Add occasion</button>
          </form>
        </div>

        <div className="card">
          <h2>Add gift idea</h2>
          <form onSubmit={addGift} noValidate>
            <input placeholder="Gift name" value={gift.name} onChange={(e) => { setGift({ ...gift, name: e.target.value }); setWarning(null); }} />
            <input type="number" min="0" placeholder="Price ₹" value={gift.price} onChange={(e) => setGift({ ...gift, price: e.target.value })} />
            <select value={gift.occasionId} onChange={(e) => setGift({ ...gift, occasionId: e.target.value })}>
              <option value="">No occasion</option>
              {occasions.map((o) => <option key={o._id} value={o._id}>{o.title}</option>)}
            </select>
            <button>Save idea</button>
          </form>
          {warning && (
            <div className="alert warn">
              <b>⚠ Possible duplicate.</b> {recipient.name} already has:
              <ul>
                {warning.map((m) => (
                  <li key={m._id}>{m.name} ({m.status}{m.dateGiven && ` on ${fmtDate(m.dateGiven)}`})</li>
                ))}
              </ul>
              <div className="row">
                <button onClick={() => saveGift(true)}>Save anyway</button>
                <button className="secondary" onClick={() => setWarning(null)}>Choose something else</button>
              </div>
            </div>
          )}
        </div>
      </div>

      <div className="grid">
        <div className="card">
          <h2>Ideas</h2>
          {!ideas.length && <p className="muted">No ideas yet.</p>}
          <ul className="plain">
            {ideas.map((g) => (
              <li key={g._id} className="row-between">
                <span>{g.name} {g.price > 0 && <span className="muted">₹{g.price}</span>}</span>
                <button className="small-btn" onClick={() => markGiven(g)}>Mark given</button>
              </li>
            ))}
          </ul>
        </div>
        <div className="card">
          <h2>Gift history</h2>
          {!given.length && <p className="muted">Nothing given yet.</p>}
          <ul className="plain">
            {given.map((g) => (
              <li key={g._id}>{g.name} · ₹{g.price} · {fmtDate(g.dateGiven)}</li>
            ))}
          </ul>
        </div>
      </div>
    </section>
  );
}

import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api, { errorMessage } from '../api';

const fmtDate = (d) => new Date(d).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });

export default function Dashboard() {
  const [upcoming, setUpcoming] = useState([]);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get('/occasions/upcoming?days=30')
      .then((res) => setUpcoming(res.data))
      .catch((err) => setError(errorMessage(err)))
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <p className="muted">Loading…</p>;

  return (
    <section>
      <h1>Upcoming occasions</h1>
      <p className="muted">Next 30 days</p>
      {error && <p className="alert error">{error}</p>}
      {!upcoming.length && !error && (
        <p className="card">Nothing in the next 30 days. <Link to="/recipients">Add an occasion</Link></p>
      )}
      <div className="grid">
        {upcoming.map((o) => {
          const pct = o.budget ? Math.min(100, Math.round((o.spent / o.budget) * 100)) : 0;
          return (
            <article key={o._id} className={`card occasion ${o.urgent ? 'urgent' : ''}`}>
              {o.urgent && <span className="badge">⚠ In {o.daysLeft === 0 ? 'today' : `${o.daysLeft} day${o.daysLeft > 1 ? 's' : ''}`}</span>}
              <h3>{o.title}</h3>
              <p className="muted">{o.recipient?.name} · {fmtDate(o.nextDate)}{!o.urgent && ` · in ${o.daysLeft} days`}</p>
              {o.budget > 0 && (
                <>
                  <div className="bar"><div style={{ width: `${pct}%` }} className={o.overBudget ? 'over' : ''} /></div>
                  <p className="small">₹{o.spent} of ₹{o.budget} spent{o.overBudget && ' — over budget!'}</p>
                </>
              )}
              {o.recipient?._id && <Link to={`/recipients/${o.recipient._id}`}>Plan gift →</Link>}
            </article>
          );
        })}
      </div>
    </section>
  );
}

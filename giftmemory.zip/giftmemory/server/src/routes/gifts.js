const router = require('express').Router();
const { body, param } = require('express-validator');
const auth = require('../middleware/auth');
const validate = require('../middleware/validate');
const asyncHandler = require('../utils/asyncHandler');
const AppError = require('../utils/AppError');
const Gift = require('../models/Gift');
const Recipient = require('../models/Recipient');
const Occasion = require('../models/Occasion');
const { isSimilar } = require('../utils/normalize');

router.use(auth);

const giftRules = [
  body('recipientId').isMongoId().withMessage('Choose a recipient'),
  body('name').trim().notEmpty().withMessage('Gift name is required').isLength({ max: 100 }),
  body('price').optional().isFloat({ min: 0 }).withMessage('Price must be 0 or more'),
  body('occasionId').optional({ values: 'falsy' }).isMongoId().withMessage('Invalid occasion'),
];

// Find gifts for this recipient whose names look like `name`
async function findDuplicates(userId, recipientId, name, excludeId) {
  const gifts = await Gift.find({ userId, recipientId });
  return gifts
    .filter((g) => String(g._id) !== String(excludeId) && isSimilar(g.name, name))
    .map((g) => ({ _id: g._id, name: g.name, status: g.status, dateGiven: g.dateGiven }));
}

async function checkOwnership(req) {
  const { recipientId, occasionId } = req.body;
  if (!(await Recipient.exists({ _id: recipientId, userId: req.userId }))) {
    throw new AppError('Recipient not found', 404);
  }
  if (occasionId && !(await Occasion.exists({ _id: occasionId, userId: req.userId }))) {
    throw new AppError('Occasion not found', 404);
  }
}

// POST /api/gifts/check-duplicate  { recipientId, name } -> { duplicate, matches }
router.post(
  '/check-duplicate',
  [
    body('recipientId').isMongoId().withMessage('Choose a recipient'),
    body('name').trim().notEmpty().withMessage('Gift name is required'),
  ],
  validate,
  asyncHandler(async (req, res) => {
    const matches = await findDuplicates(req.userId, req.body.recipientId, req.body.name);
    res.json({ duplicate: matches.length > 0, matches });
  })
);

router.get('/', asyncHandler(async (req, res) => {
  const filter = { userId: req.userId };
  if (req.query.recipientId) filter.recipientId = req.query.recipientId;
  if (req.query.status) filter.status = req.query.status;
  const gifts = await Gift.find(filter).populate('recipientId', 'name').sort({ createdAt: -1 });
  res.json(gifts);
}));

// Create a gift idea. If it duplicates a past gift, respond 409
// unless the client sends { force: true } after the user confirms.
router.post('/', giftRules, validate, asyncHandler(async (req, res) => {
  await checkOwnership(req);
  const { recipientId, occasionId, name, price, force } = req.body;
  const matches = await findDuplicates(req.userId, recipientId, name);
  if (matches.length && !force) {
    throw new AppError('Possible duplicate gift', 409, { matches });
  }
  const gift = await Gift.create({
    userId: req.userId, recipientId, occasionId: occasionId || undefined, name, price,
  });
  res.status(201).json(gift);
}));

// PATCH /api/gifts/:id/given  { price?, dateGiven? }
router.patch(
  '/:id/given',
  [
    param('id').isMongoId(),
    body('price').optional().isFloat({ min: 0 }).withMessage('Price must be 0 or more'),
    body('dateGiven').optional().isISO8601().withMessage('Enter a valid date'),
  ],
  validate,
  asyncHandler(async (req, res) => {
    const gift = await Gift.findOne({ _id: req.params.id, userId: req.userId });
    if (!gift) throw new AppError('Gift not found', 404);
    gift.status = 'given';
    gift.dateGiven = req.body.dateGiven || new Date();
    if (req.body.price !== undefined) gift.price = req.body.price;
    await gift.save();
    res.json(gift);
  })
);

router.delete('/:id', [param('id').isMongoId()], validate, asyncHandler(async (req, res) => {
  const g = await Gift.findOneAndDelete({ _id: req.params.id, userId: req.userId });
  if (!g) throw new AppError('Gift not found', 404);
  res.status(204).end();
}));

module.exports = router;

const router = require('express').Router();
const { body, param, query } = require('express-validator');
const auth = require('../middleware/auth');
const validate = require('../middleware/validate');
const asyncHandler = require('../utils/asyncHandler');
const AppError = require('../utils/AppError');
const Occasion = require('../models/Occasion');
const Recipient = require('../models/Recipient');
const Gift = require('../models/Gift');
const { nextOccurrence, daysUntil } = require('../utils/dates');

router.use(auth);

const rules = [
  body('recipientId').isMongoId().withMessage('Choose a recipient'),
  body('title').trim().notEmpty().withMessage('Title is required').isLength({ max: 80 }),
  body('date').isISO8601().withMessage('Enter a valid date'),
  body('recurring').optional().isBoolean(),
  body('budget').optional().isFloat({ min: 0 }).withMessage('Budget must be 0 or more'),
];

const checkRecipient = async (req) => {
  const ok = await Recipient.exists({ _id: req.body.recipientId, userId: req.userId });
  if (!ok) throw new AppError('Recipient not found', 404);
};

// GET /api/occasions/upcoming?days=30  -> occasions in the next N days
router.get(
  '/upcoming',
  [query('days').optional().isInt({ min: 1, max: 366 }).withMessage('days must be 1-366')],
  validate,
  asyncHandler(async (req, res) => {
    const days = Number(req.query.days) || 30;
    const occasions = await Occasion.find({ userId: req.userId }).populate('recipientId', 'name');

    const upcoming = [];
    for (const o of occasions) {
      const next = nextOccurrence(o.date, o.recurring);
      const inDays = daysUntil(next);
      if (inDays < 0 || inDays > days) continue;

      // Budget spent = gifts given for this occasion
      const given = await Gift.find({ userId: req.userId, occasionId: o._id, status: 'given' });
      const spent = given.reduce((sum, g) => sum + (g.price || 0), 0);

      upcoming.push({
        _id: o._id,
        title: o.title,
        recipient: o.recipientId,
        nextDate: next,
        daysLeft: inDays,
        urgent: inDays <= 7,
        budget: o.budget,
        spent,
        overBudget: o.budget > 0 && spent > o.budget,
      });
    }
    upcoming.sort((a, b) => a.daysLeft - b.daysLeft);
    res.json(upcoming);
  })
);

router.get('/', asyncHandler(async (req, res) => {
  const list = await Occasion.find({ userId: req.userId }).populate('recipientId', 'name').sort({ date: 1 });
  res.json(list);
}));

router.post('/', rules, validate, asyncHandler(async (req, res) => {
  await checkRecipient(req);
  const { recipientId, title, date, recurring, budget } = req.body;
  const o = await Occasion.create({ userId: req.userId, recipientId, title, date, recurring, budget });
  res.status(201).json(o);
}));

router.put('/:id', [param('id').isMongoId(), ...rules], validate, asyncHandler(async (req, res) => {
  await checkRecipient(req);
  const o = await Occasion.findOneAndUpdate(
    { _id: req.params.id, userId: req.userId },
    (({ recipientId, title, date, recurring, budget }) => ({ recipientId, title, date, recurring, budget }))(req.body),
    { new: true, runValidators: true }
  );
  if (!o) throw new AppError('Occasion not found', 404);
  res.json(o);
}));

router.delete('/:id', [param('id').isMongoId()], validate, asyncHandler(async (req, res) => {
  const o = await Occasion.findOneAndDelete({ _id: req.params.id, userId: req.userId });
  if (!o) throw new AppError('Occasion not found', 404);
  res.status(204).end();
}));

module.exports = router;

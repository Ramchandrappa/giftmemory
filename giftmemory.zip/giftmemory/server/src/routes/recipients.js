const router = require('express').Router();
const { body, param } = require('express-validator');
const auth = require('../middleware/auth');
const validate = require('../middleware/validate');
const asyncHandler = require('../utils/asyncHandler');
const AppError = require('../utils/AppError');
const Recipient = require('../models/Recipient');
const Occasion = require('../models/Occasion');
const Gift = require('../models/Gift');

router.use(auth);

const rules = [
  body('name').trim().notEmpty().withMessage('Name is required').isLength({ max: 60 }),
  body('relationship').optional().trim().isLength({ max: 40 }),
  body('preferences.likes').optional().isArray().withMessage('Likes must be a list'),
  body('preferences.dislikes').optional().isArray().withMessage('Dislikes must be a list'),
  body('preferences.sizes').optional().trim().isLength({ max: 100 }),
  body('preferences.notes').optional().trim().isLength({ max: 500 }),
];
const idRule = [param('id').isMongoId().withMessage('Invalid id')];

// Every query includes userId, so users only ever see their own data
const findOwn = async (req) => {
  const r = await Recipient.findOne({ _id: req.params.id, userId: req.userId });
  if (!r) throw new AppError('Recipient not found', 404);
  return r;
};

router.get('/', asyncHandler(async (req, res) => {
  const list = await Recipient.find({ userId: req.userId }).sort({ name: 1 });
  res.json(list);
}));

router.post('/', rules, validate, asyncHandler(async (req, res) => {
  const { name, relationship, preferences } = req.body;
  const r = await Recipient.create({ userId: req.userId, name, relationship, preferences });
  res.status(201).json(r);
}));

router.get('/:id', idRule, validate, asyncHandler(async (req, res) => {
  const recipient = await findOwn(req);
  const [occasions, gifts] = await Promise.all([
    Occasion.find({ userId: req.userId, recipientId: recipient._id }).sort({ date: 1 }),
    Gift.find({ userId: req.userId, recipientId: recipient._id }).sort({ createdAt: -1 }),
  ]);
  res.json({ recipient, occasions, gifts });
}));

router.put('/:id', [...idRule, ...rules], validate, asyncHandler(async (req, res) => {
  const r = await findOwn(req);
  const { name, relationship, preferences } = req.body;
  Object.assign(r, { name, relationship, preferences });
  await r.save();
  res.json(r);
}));

router.delete('/:id', idRule, validate, asyncHandler(async (req, res) => {
  const r = await findOwn(req);
  await Promise.all([
    Occasion.deleteMany({ userId: req.userId, recipientId: r._id }),
    Gift.deleteMany({ userId: req.userId, recipientId: r._id }),
    r.deleteOne(),
  ]);
  res.status(204).end();
}));

module.exports = router;

const jwt = require('jsonwebtoken');
const AppError = require('../utils/AppError');

// Reads "Authorization: Bearer <token>" and sets req.userId
module.exports = (req, res, next) => {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) return next(new AppError('Please log in to continue', 401));
  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    req.userId = payload.id;
    next();
  } catch {
    next(new AppError('Session expired, please log in again', 401));
  }
};

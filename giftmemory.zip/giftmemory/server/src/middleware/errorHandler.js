// Turns every error into a consistent JSON response
module.exports = (err, req, res, next) => {
  let status = err.statusCode || 500;
  let message = err.message || 'Something went wrong';
  let details = err.details;

  if (err.name === 'CastError') {
    status = 400;
    message = 'Invalid id';
  } else if (err.name === 'ValidationError') {
    status = 400;
    message = 'Validation failed';
    details = Object.values(err.errors).map((e) => ({ field: e.path, message: e.message }));
  } else if (err.code === 11000) {
    status = 409;
    message = 'That email is already registered';
  }

  if (status === 500) console.error(err);

  res.status(status).json({
    error: { message: status === 500 ? 'Internal server error' : message, details },
  });
};

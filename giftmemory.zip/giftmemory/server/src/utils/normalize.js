// "  Bluetooth Speaker!! " -> "bluetooth speaker"
function normalizeName(name = '') {
  return name
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

// Simple similarity: exact match, one name contains the other,
// or they share most of their words.
function isSimilar(a, b) {
  const x = normalizeName(a);
  const y = normalizeName(b);
  if (!x || !y) return false;
  if (x === y || x.includes(y) || y.includes(x)) return true;
  const wa = new Set(x.split(' '));
  const wb = new Set(y.split(' '));
  const common = [...wa].filter((w) => wb.has(w)).length;
  return common / Math.max(wa.size, wb.size) >= 0.6;
}

module.exports = { normalizeName, isSimilar };

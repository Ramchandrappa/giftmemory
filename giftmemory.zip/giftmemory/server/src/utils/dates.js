// Next date an occasion happens on or after today.
// Yearly occasions roll forward to this year or next year.
function startOfDay(d) {
  return new Date(d.getFullYear(), d.getMonth(), d.getDate());
}

function nextOccurrence(date, recurring, from = new Date()) {
  const d = new Date(date);
  const today = startOfDay(from);
  if (!recurring) return startOfDay(d);
  let next = new Date(today.getFullYear(), d.getMonth(), d.getDate());
  if (next < today) next = new Date(today.getFullYear() + 1, d.getMonth(), d.getDate());
  return next;
}

function daysUntil(target, from = new Date()) {
  return Math.round((startOfDay(target) - startOfDay(from)) / 86400000);
}

module.exports = { nextOccurrence, daysUntil };

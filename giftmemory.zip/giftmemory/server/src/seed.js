// Creates a demo account: demo@giftmemory.app / demo123
require('dotenv').config();
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const User = require('./models/User');
const Recipient = require('./models/Recipient');
const Occasion = require('./models/Occasion');
const Gift = require('./models/Gift');

(async () => {
  await mongoose.connect(process.env.MONGO_URI);
  const email = 'demo@giftmemory.app';
  const old = await User.findOne({ email });
  if (old) {
    await Promise.all([
      Recipient.deleteMany({ userId: old._id }),
      Occasion.deleteMany({ userId: old._id }),
      Gift.deleteMany({ userId: old._id }),
      old.deleteOne(),
    ]);
  }

  const user = await User.create({ name: 'Demo User', email, passwordHash: await bcrypt.hash('demo123', 10) });
  const mom = await Recipient.create({
    userId: user._id, name: 'Mom', relationship: 'Mother',
    preferences: { likes: ['gardening', 'books'], dislikes: ['perfume'], sizes: 'M', notes: 'Loves plants' },
  });

  const in5Days = new Date();
  in5Days.setDate(in5Days.getDate() + 5);
  const birthday = await Occasion.create({
    userId: user._id, recipientId: mom._id, title: "Mom's Birthday", date: in5Days, recurring: true, budget: 3000,
  });

  const g = new Gift({
    userId: user._id, recipientId: mom._id, name: 'Silk saree', price: 2500,
    status: 'given', dateGiven: new Date('2024-06-10'),
  });
  await g.save();

  console.log('Seeded. Log in with demo@giftmemory.app / demo123');
  console.log('Occasion id:', birthday._id.toString());
  await mongoose.disconnect();
})();

const mongoose = require('mongoose');

const recipientSchema = new mongoose.Schema(
  {
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    name: { type: String, required: true, trim: true, maxlength: 60 },
    relationship: { type: String, trim: true, maxlength: 40 },
    preferences: {
      likes: [{ type: String, trim: true }],
      dislikes: [{ type: String, trim: true }],
      sizes: { type: String, trim: true, maxlength: 100 },
      notes: { type: String, trim: true, maxlength: 500 },
    },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Recipient', recipientSchema);

const mongoose = require('mongoose');

const occasionSchema = new mongoose.Schema(
  {
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    recipientId: { type: mongoose.Schema.Types.ObjectId, ref: 'Recipient', required: true },
    title: { type: String, required: true, trim: true, maxlength: 80 },
    date: { type: Date, required: true },
    recurring: { type: Boolean, default: true },
    budget: { type: Number, min: 0, default: 0 },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Occasion', occasionSchema);

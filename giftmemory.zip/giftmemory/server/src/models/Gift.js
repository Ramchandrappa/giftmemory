const mongoose = require('mongoose');
const { normalizeName } = require('../utils/normalize');

const giftSchema = new mongoose.Schema(
  {
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    recipientId: { type: mongoose.Schema.Types.ObjectId, ref: 'Recipient', required: true, index: true },
    occasionId: { type: mongoose.Schema.Types.ObjectId, ref: 'Occasion' },
    name: { type: String, required: true, trim: true, maxlength: 100 },
    normalizedName: { type: String, index: true },
    price: { type: Number, min: 0, default: 0 },
    status: { type: String, enum: ['idea', 'given'], default: 'idea' },
    dateGiven: { type: Date },
  },
  { timestamps: true }
);

// Keep a normalised copy of the name for duplicate checks
giftSchema.pre('save', function (next) {
  this.normalizedName = normalizeName(this.name);
  next();
});

module.exports = mongoose.model('Gift', giftSchema);

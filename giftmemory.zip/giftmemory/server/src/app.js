const express = require('express');
const cors = require('cors');
const errorHandler = require('./middleware/errorHandler');
const AppError = require('./utils/AppError');

const app = express();

app.use(cors({ origin: process.env.CLIENT_URL || 'http://localhost:5173' }));
app.use(express.json({ limit: '100kb' }));

app.get('/api/health', (req, res) => res.json({ status: 'ok' }));

app.use('/api/auth', require('./routes/auth'));
app.use('/api/recipients', require('./routes/recipients'));
app.use('/api/occasions', require('./routes/occasions'));
app.use('/api/gifts', require('./routes/gifts'));

// Unknown route -> 404
app.use((req, res, next) => next(new AppError(`Route not found: ${req.originalUrl}`, 404)));

// Central error handler (must be last)
app.use(errorHandler);

module.exports = app;
